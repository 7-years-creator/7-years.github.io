#include<iostream>
#include<string>
#include"skiplist.h"
#include<cmath>
#include <pthread.h>
#include <chrono>
#include <time.h>
#include <fstream>
using namespace std;

#define NUM_THREADS 1
#define TEST_COUNT 100000//测试数据
skipList<int, string> my_SkipList(18);//层高

void *insertElement(void*) 
{
    int tmp = TEST_COUNT/NUM_THREADS; 
	for (int count=0; count<tmp;count++) 
    {
		my_SkipList.insertNode(rand() % TEST_COUNT, "a"); 
        
	}
    pthread_exit(NULL);
}

void *getElement(void*) 
{
    int tmp = TEST_COUNT/NUM_THREADS; 
	for (int count=0; count<tmp; count++) 
    {    
		my_SkipList.searchNode(rand() % TEST_COUNT); 
	}
    pthread_exit(NULL);
}

int main()
{
	srand (time(NULL));  
    {
        pthread_t threads[NUM_THREADS];
        int rc;
        int i;

        auto start = std::chrono::high_resolution_clock::now();

        for( i = 0; i < NUM_THREADS; i++ ) 
        {
            std::cout << "main() : creating thread, " << i << std::endl;
            rc = pthread_create(&threads[i], NULL, insertElement, NULL);
            if (rc) 
            {
                std::cout << "Error:unable to create thread," << rc << std::endl;
                exit(-1);
            }
        }

        void *ret;
        for( i = 0; i < NUM_THREADS; i++ ) 
        {
            if (pthread_join(threads[i], &ret) !=0)  
            {
                perror("pthread_create() error"); 
                exit(3);
            }
        }
        auto finish = std::chrono::high_resolution_clock::now(); 
        std::chrono::duration<double> elapsed = finish - start;
        std::cout << "insert elapsed:" << elapsed.count() << std::endl;
        std::cout<<"element :"<<my_SkipList.size()<<std::endl;
        
    }
    /*my_SkipList.insertNode(0, "this is a program");
	my_SkipList.insertNode(1, "You can insert data");
	my_SkipList.insertNode(2, "You can delete data");
	my_SkipList.insertNode(3, "You can query the data");
	my_SkipList.insertNode(4, "You can show the data");
    my_SkipList.dump_file();
	my_SkipList.displayList();*/

	return 0;
}
