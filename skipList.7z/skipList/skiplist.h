#include<iostream>
#include<cstdlib>
#include<cstring>
#include<cmath>
#include <mutex>
#include <fstream>
#define STORE_FILE "store/dumpFile"
std::mutex mtx;     // mutex for critical section
std::string delimiter = ":";
//节点类
template<typename K,typename V>//K为键值，V为对应的value
class Node
{
public:
	Node() {};//默认构造函数
	Node(K k, V v, int);//构造函数，传入层数
	~Node();//析构函数
	K getKey() const;//得到键值
	V getValue() const;//得到键值对应的value
	void setValue(V);//设定值
	Node<K, V> **forward;//设定的层数为从0开始
	int nodeLevel;
private:
	K key;
	V value;
};

//构造函数
template<typename K, typename V>
Node<K,V>::Node(K k, V v, int level)//初始化
{
	this->key = k;
	this->value = v;
	this->nodeLevel = level;
	this->forward = new Node<K, V>*[level + 1];
	//将指针数组初始化为0；
	memset(this->forward, 0, sizeof(Node<K, V>*)*(level + 1));
}
template<typename K, typename V>
Node<K, V>::~Node()//析构函数，释放内存
{
	delete []forward;
}
template<typename K, typename V>
K Node<K, V>::getKey() const//得到键值
{
	return this->key;
}
template<typename K, typename V>
V Node<K, V>::getValue() const//得到键值对应的值
{
	return this->value;
}
template<typename K, typename V>
void Node<K, V>::setValue(V value)//设定值
{
	this->value = value;
}

//跳表类
template <typename K, typename V>
class skipList
{
public:
	skipList(int);//构造函数
	~skipList();//析构函数
	int getRandomLevel();//得到随机层数
	Node<K, V>* creatNode(K, V, int);//创建一个结点
	int insertNode(K, V);//插入一个结点
	bool searchNode(K);//查找一个结点
	void deleteNode(K);//删除一个节点
	void displayList();//显示跳表
	int size();//返回跳表中结点的个数
	void dump_file();//数据落盘
	void load_file();//数据加载
private:
    void get_key_value_from_string(const std::string& str, std::string* key, std::string* value);
    bool is_valid_string(const std::string& str);

private:
	int maxLevel;//跳表最大层高
	int currentLevel;//跳表当前层高
	int countElement;//跳表中结点的个数
	std::ofstream _file_writer;//文件操作
    std::ifstream _file_reader;
	Node<K, V> *head;//头结点
};

template<typename K, typename V>
skipList<K, V>::skipList(int maxLevel)
{
	this->maxLevel = maxLevel;
	this->currentLevel = 0;
	this->countElement = 0;
	K k = -INT8_MAX;
	V v;
	this->head = new Node<K, V>(k, v, maxLevel);//maxLevel涉及到指针指向的数组有多大，也就是最大层高
}
template<typename K, typename V>
skipList<K, V>::~skipList()//析构函数
{
	if (_file_writer.is_open()) 
	{
        _file_writer.close();
    }
    if (_file_reader.is_open()) 
	{
        _file_reader.close();
    }
	delete head;//释放内存
}
template<typename K, typename V>
int skipList<K, V>::getRandomLevel()//得到随机层数
{
	int k = 1;//层数
	while (rand() % 2)//每次晋升的概率为0.5,通过随机数为奇数或偶数各位0.5的概率实现
	{
		k++;
	}
	k = (k < maxLevel ? k : maxLevel);//超过规定的最高层数，那么就取最高层数
	return k;
}
template<typename K, typename V>
Node<K, V>* skipList<K,V>:: creatNode(const K k, const V v, int level)//创建一个结点,这个level通过随机层数得到
{
	Node<K, V>* newNode = new Node<K,V>(k, v, level);
	return newNode;
}

/*
						   +------------+
						   |  insert 50 |
						   +------------+
level 4     +-->1+                                                      100
				 |
				 |                      insert +----+
level 3         1+-------->10+---------------> | 50 |          70       100
											   |    |
											   |    |
level 2         1          10         30       | 50 |          70       100
											   |    |
											   |    |
level 1         1    4     10         30       | 50 |          70       100
											   |    |
											   |    |
level 0         1    4   9 10         30   40  | 50 |  60      70       100
											   +----+

*/
//返回0代表插入成功
//返回1代表结点已存在
template<typename K, typename V>
int skipList<K, V> ::insertNode(K key, V value)//插入一个结点
{
	mtx.lock();
	Node<K, V>* currentNode = head;//定义一个当前节点，指向头结点
	Node<K, V> **updata;//定义一个数组指针，保留每层当中要插入节点的前一个位置
	updata = new Node<K, V>*[maxLevel + 1];
	memset(updata, 0, sizeof(Node<K, V>*)*(maxLevel + 1));
	for (int i = currentLevel; i >= 0; i--)//这里用于降层
	{	//当该层当前节点的下一个节点存在，并且下一个节点的的键值小于要插入的键值
		while (currentNode->forward[i] != nullptr&&currentNode->forward[i]->getKey() < key)
		{	//使当前节点指向下一个节点，否则降层，i--代表降层
			currentNode = currentNode->forward[i];
		}
		updata[i] = currentNode;//保存该层降层之前的最后一个节点
	}
	//走到第0层的时候，代表下一个结点就是要插入的地方了
	currentNode = currentNode->forward[0];//updata保存了前一个结点
	if (currentNode != nullptr&&currentNode->getKey() == key)//如果下一个节点的键值等于要插入节点的键值，那么返回 1
	{
		//std::cout << "key : " << key << ", exist ! " << std::endl;
		mtx.unlock();
		return 1;
	}
	if (currentNode == nullptr || currentNode->getKey() != key)//如果下一个节点不存在或者下一个节点的键值不存在，那么在此处插入
	{
		int randomLevel = getRandomLevel();//得到随机层数
		if (randomLevel > currentLevel)//如果随机的层数大于当前链表的层数
		{
			for (int i = currentLevel + 1; i < randomLevel; i++)
			{
				updata[i] = head;//就让多出来的层数直接用head指向他
			}
			currentLevel = randomLevel;
		}
		Node<K, V>* insertNode = creatNode(key, value, randomLevel);//创建出这个结点
		//开始插入
		for (int i = 0; i < randomLevel; i++)
		{
			insertNode->forward[i] = updata[i]->forward[i];//让保存的结点和这个结点指来指去就好了
			updata[i]->forward[i] = insertNode;
		}
		//std::cout << "successfully inserted key: " << key << ", value" << value << std::endl;
		countElement++;//元素个数加一
	}
	mtx.unlock();
	return 0;//返回0代表插入成功
}


/*
						   +------------+
						   |  select 60 |
						   +------------+
level 4     +-->1+                                                      100
				 |
				 |
level 3         1+-------->10+------------------>50+           70       100
												   |
												   |
level 2         1          10         30         50|           70       100
												   |
												   |
level 1         1    4     10         30         50|           70       100
												   |
												   |
level 0         1    4   9 10         30   40    50+-->60      70       100
*/

template<typename K, typename V>//查找一个结点
bool skipList<K,V>::searchNode(K key)
{
	Node<K, V>* currentNode = head;//定义一个当前节点，指向头结点
	for (int i = currentLevel; i >= 0; i--)//这里用于降层
	{	//当该层当前节点的下一个节点存在，并且下一个节点的的键值小于要插入的键值
		while (currentNode->forward[i] != nullptr&&currentNode->forward[i]->getKey() < key)
		{	//使当前节点指向下一个节点，否则降层，i--代表降层
			currentNode = currentNode->forward[i];
		}
	}
	currentNode = currentNode->forward[0];//第一层的下一个结点就是比较对象
	if (currentNode&&currentNode->getKey() == key)//找到了
	{
		std::cout << "Found key: " << key << ", value: " << currentNode->getValue() << std::endl;
		return true;
	}
	else//没找到
	{
		std::cout << "Not Found Key:" << key << std::endl;
		return false;
	}
}
template<typename K, typename V>
void skipList<K, V>::deleteNode(K key)//删除一个节点
{
	mtx.lock();
	Node<K, V>* currentNode = head;//定义一个当前节点，指向头结点
	Node<K, V> **updata;//定义一个数组指针，保留每层当中要插入节点的前一个位置
	updata = new Node<K, V>*[maxLevel + 1];
	memset(updata, 0, sizeof(Node<K, V>*)*(maxLevel + 1));
	for (int i = currentLevel; i >= 0; i--)//这里用于降层
	{	//当该层当前节点的下一个节点存在，并且下一个节点的的键值小于要插入的键值
		while (currentNode->forward[i] != nullptr&&currentNode->forward[i]->getKey() < key)
		{	//使当前节点指向下一个节点，否则降层，i--代表降层
			currentNode = currentNode->forward[i];
		}
		updata[i] = currentNode;//保存该层降层之前的最后一个节点
	}
	currentNode = currentNode->forward[0];
	if (currentNode != nullptr&&currentNode->getKey() == key)//找到了要删除的结点
	{
		for (int i = 0; i < currentLevel; i++)//这里升层
		{
			if (updata[i]->forward[i] != currentNode)
			{
				break;//表示这个结点就只有这么多层
			}
			updata[i]->forward[i] = currentNode->forward[i];//删除掉
		}
		//可能需要移除一层
		while (currentLevel > 0 && head->forward[currentLevel] == 0)
		{
			currentLevel--;//删掉这一层
		}
		std::cout << "Successfully deleted key " << key << std::endl;
		countElement--;
	}
	mtx.unlock();
	return;
}
template<typename K, typename V>
void skipList<K,V>:: displayList()//显示跳表
{
	std::cout << "\n*****Skip List*****" << "\n";
	for (int i = 0; i <= currentLevel; i++)
	{
		Node<K, V> *node = this->head->forward[i];//从第0层开始
		std::cout << "Level " << i << ": ";
		while (node != nullptr)
		{
			std::cout << node->getKey() << " : " << node->getValue() << " ";
			node = node->forward[i];//往前走
		}
		std::cout << std::endl;
	}
}
template<typename K, typename V>
int skipList<K, V>::size()
{
	return this->countElement;
}
// Dump data in memory to file 
template<typename K, typename V> 
void skipList<K, V>::dump_file() 
{
    std::cout << "dump_file-----------------" << std::endl;
    _file_writer.open(STORE_FILE);
	if (!_file_writer.is_open()) 
    { 
        std::cout << "未成功打开文件" << std::endl; 
    }
    Node<K, V> *node = this->head->forward[0]; 

    while (node != NULL) 
	{
        _file_writer << node->getKey() << ":" << node->getValue() << "\n";
        //std::cout << node->getKey() << ":" << node->getValue() << ";\n";
        node = node->forward[0];
    }
    _file_writer.flush();
    _file_writer.close();
    return ;
}
template<typename K, typename V>
void skipList<K, V>::get_key_value_from_string(const std::string& str, std::string* key, std::string* value) 
{
    if(!is_valid_string(str)) 
	{
        return;
    }
    *key = str.substr(0, str.find(delimiter));
    *value = str.substr(str.find(delimiter)+1, str.length());
}

template<typename K, typename V>
bool skipList<K, V>::is_valid_string(const std::string& str) 
{
    if (str.empty()) 
	{
        return false;
    }
    if (str.find(delimiter) == std::string::npos) 
	{
        return false;
    }
    return true;
}
template<typename K, typename V> 
void skipList<K, V>::load_file() 
{
    _file_reader.open(STORE_FILE);
    std::cout << "load_file-----------------" << std::endl;
    std::string line;
    std::string* key = new std::string();
    std::string* value = new std::string();
    while (getline(_file_reader, line)) 
	{
        get_key_value_from_string(line, key, value);
        if (key->empty() || value->empty()) 
		{
            continue;
        }
		
        //insertNode(*key, *value);
        std::cout << "key:" << *key << "value:" << *value << std::endl;
    }
    _file_reader.close();
}